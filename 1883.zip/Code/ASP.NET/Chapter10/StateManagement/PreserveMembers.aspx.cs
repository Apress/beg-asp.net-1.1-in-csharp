using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace StateManagement
{
	/// <summary>
	/// Summary description for PreserveMembers.
	/// </summary>
	public class PreserveMembers : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.TextBox txtValue;
		protected System.Web.UI.WebControls.Button cmdLoad;
		protected System.Web.UI.WebControls.Button cmdSave;
	
		// A member variable that will be cleared with every postback.
		private string contents;

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (this.IsPostBack)
			{
				// Restore variables.
				contents = (string)ViewState["Text"];
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.cmdLoad.Click += new System.EventHandler(this.cmdLoad_Click);
			this.cmdSave.Click += new System.EventHandler(this.cmdSave_Click);
			this.Load += new System.EventHandler(this.Page_Load);
			this.PreRender += new System.EventHandler(this.PreserveMembers_PreRender);

		}
		#endregion

		private void PreserveMembers_PreRender(object sender, System.EventArgs e)
		{
			// Persist variables.
			ViewState["Text"] = contents;
		}

		private void cmdLoad_Click(object sender, System.EventArgs e)
		{
			// Restore contents of member variable to text box.
			txtValue.Text = contents;

		}

		private void cmdSave_Click(object sender, System.EventArgs e)
		{
			// Transfer contents of text box to member variable.
			contents = txtValue.Text;
			txtValue.Text = "";

		}
	}
}
