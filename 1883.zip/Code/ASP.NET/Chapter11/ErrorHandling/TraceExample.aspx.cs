using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace ErrorHandling
{
	/// <summary>
	/// Summary description for TraceExample.
	/// </summary>
	public class TraceExample : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Button cmdWrite;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Button cmdWriteCategory;
		protected System.Web.UI.WebControls.Button cmdError;
		protected System.Web.UI.WebControls.Button cmdSession;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			Trace.IsEnabled = true;
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.cmdWrite.Click += new System.EventHandler(this.cmdWrite_Click);
			this.cmdWriteCategory.Click += new System.EventHandler(this.cmdWriteCategory_Click);
			this.cmdError.Click += new System.EventHandler(this.cmdError_Click);
			this.cmdSession.Click += new System.EventHandler(this.cmdSession_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void cmdWrite_Click(object sender, System.EventArgs e)
		{
			
			Trace.Write("About to place an item in session state.");
			Session["Test"] = "Contents";
			Trace.Write("Placed item in session state.");

		}

		private void cmdWriteCategory_Click(object sender, System.EventArgs e)
		{
			Trace.Write("Page_Load", "About to place an item in session state.");
			Session["Test"] = "This is just a string";
			Trace.Write("Page_Load", "Placed item in session state.");

		}


		private decimal DivideNumbers(decimal number, decimal divisor)
		{
			return number/divisor;
		}

		private void cmdError_Click(object sender, System.EventArgs e)
		{
			try
			{
				DivideNumbers(5, 0);
			}
			catch (Exception err)
			{
				Trace.Warn("cmdError_Click", "Caught Error", err);
			}

		}

		private void cmdSession_Click(object sender, System.EventArgs e)
		{
			DataSet ds = new DataSet();
			Session["MyDataSet"] = ds;
		}

	}
}
