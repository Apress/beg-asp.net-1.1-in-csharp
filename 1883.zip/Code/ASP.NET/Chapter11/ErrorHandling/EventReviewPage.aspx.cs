using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Diagnostics;

namespace ErrorHandling
{
	/// <summary>
	/// Summary description for EventReviewPage.
	/// </summary>
	public class EventReviewPage : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label lblResult;
		protected System.Web.UI.WebControls.TextBox txtLog;
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.TextBox txtSource;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Button cmdGet;
		protected System.Web.UI.WebControls.CheckBox chkAll;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.cmdGet.Click += new System.EventHandler(this.cmdGet_Click);
			this.chkAll.CheckedChanged += new System.EventHandler(this.chkAll_CheckedChanged);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void chkAll_CheckedChanged(object sender, System.EventArgs e)
		{
			// The chkAll control has AutoPostback = true.
			if (chkAll.Checked == true)
			{
				txtSource.Text = "";
				txtSource.Enabled = false;
			}
			else
			{
				txtSource.Enabled = true;
			}

		}

		private void cmdGet_Click(object sender, System.EventArgs e)
		{
			
			// Check if the log exists.
			if (!EventLog.Exists(txtLog.Text))
			{
				lblResult.Text = "The event log " + txtLog.Text ;
				lblResult.Text += " doesn't exist.";
			}
			else
			{
				// For maximum performance, join all the event
				// information into one large string using the
				// StringBuilder.
				System.Text.StringBuilder sb = new System.Text.StringBuilder();

				EventLog log = new EventLog(txtLog.Text);
				foreach (EventLogEntry entry in log.Entries)
				{
					// Write the event entries to the page.
					if (chkAll.Checked == true ||
						entry.Source == txtSource.Text)
					{
						sb.Append("<b>Entry Type:</b> ");
						sb.Append(entry.EntryType.ToString());
						sb.Append("<br><b>Message:</b> ");
						sb.Append(entry.Message);
						sb.Append("<br><b>Time Generated:</b> ");
						sb.Append(entry.TimeGenerated);
						sb.Append("<br><br>");
					}
					lblResult.Text = sb.ToString();
				}
			}

		}
	}
}
