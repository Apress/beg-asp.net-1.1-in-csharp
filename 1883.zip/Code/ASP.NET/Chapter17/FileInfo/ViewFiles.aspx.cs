using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.IO;

namespace FileInfo
{
	/// <summary>
	/// Summary description for ViewFiles.
	/// </summary>
	public class ViewFiles : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.ListBox lstFiles;
		protected System.Web.UI.WebControls.Button cmdRefresh;
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.Label lblFileInfo;
		protected System.Web.UI.WebControls.Button cmdDelete;

		string ftpDirectory = @"c:\Temp";

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!this.IsPostBack)
			{
				CreateFileList();
			}
		}

		private void CreateFileList()
		{
			// Retrieve the list of files, and display it in the page.
			// This code also disables the delete button, ensuring the
			// user must view the file information before deleting it.
			string[] fileList = Directory.GetFiles(ftpDirectory);
			lstFiles.DataSource = fileList;
			lstFiles.DataBind();
			lblFileInfo.Text = "";
			cmdDelete.Enabled = false;
		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.lstFiles.SelectedIndexChanged += new System.EventHandler(this.lstFiles_SelectedIndexChanged);
			this.cmdRefresh.Click += new System.EventHandler(this.cmdRefresh_Click);
			this.cmdDelete.Click += new System.EventHandler(this.cmdDelete_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void cmdRefresh_Click(object sender, System.EventArgs e)
		{
			    CreateFileList();
		}

		private void cmdDelete_Click(object sender, System.EventArgs e)
		{
			File.Delete(lstFiles.SelectedItem.Text);
			CreateFileList();

		}

		private void lstFiles_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			// Display the selected file information.
			// This control has AutoPostback = true.
			string fileName = lstFiles.SelectedItem.Text;
			lblFileInfo.Text = "<b>" + fileName + "</b><br>";
			lblFileInfo.Text += "Created : ";
			lblFileInfo.Text += File.GetCreationTime(fileName).ToString();
			lblFileInfo.Text += "<br>Last Accessed : ";
			lblFileInfo.Text += File.GetLastAccessTime(fileName).ToString();
			lblFileInfo.Text += "<br>";

			// Show attribute information. GetAttributes() can return a combination
			// of enumerated values, so you need to evaluate it with the
			// bitwise and (&) operator.
			FileAttributes attributes = File.GetAttributes(fileName);
			if ((attributes & FileAttributes.Hidden) == FileAttributes.Hidden)
			{
				lblFileInfo.Text += "This is a hidden file." + "<br>";
			}
			if ((attributes & FileAttributes.ReadOnly) == FileAttributes.ReadOnly)
			{
				lblFileInfo.Text += "This is a read-only file." + "<br>";
			}

			// Allow the file to be deleted.
			if ((attributes & FileAttributes.ReadOnly) != FileAttributes.ReadOnly)
			{
				cmdDelete.Enabled = true;
			}
			else
			{
				cmdDelete.Enabled = false;
			}

		}
	}
}
