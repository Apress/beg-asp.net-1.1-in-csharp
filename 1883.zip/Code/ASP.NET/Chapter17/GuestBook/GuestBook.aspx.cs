using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.IO;

namespace GuestBook
{
	/// <summary>
	/// Summary description for GuestBook.
	/// </summary>
	public class GuestBook : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.DataList GuestBookList;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.TextBox txtName;
		protected System.Web.UI.WebControls.TextBox txtMessage;
		protected System.Web.UI.WebControls.Button cmdSubmit;

	    private string guestBookName;

		private void Page_Load(object sender, System.EventArgs e)
		{
			guestBookName = Server.MapPath("GuestBook");

			if (!this.IsPostBack)
			{
				GuestBookList.DataSource = GetAllEntries();
				GuestBookList.DataBind();
			}

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.cmdSubmit.Click += new System.EventHandler(this.cmdSubmit_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void cmdSubmit_Click(object sender, System.EventArgs e)
		{
			// Create a new BookEntry object.
			BookEntry newEntry = new BookEntry();
			newEntry.Author = txtName.Text;
			newEntry.Submitted = DateTime.Now;
			newEntry.Message = txtMessage.Text;

			// Let the SaveEntry procedure create the corresponding file.
			SaveEntry(newEntry);

			// Refresh the display.
			GuestBookList.DataSource = GetAllEntries();
			GuestBookList.DataBind();

			txtName.Text = "";
			txtMessage.Text = "";
		}

		private ArrayList GetAllEntries()
		{
			// Return an ArrayList that contains BookEntry objects
			// for each file in the GuestBook directory.
			// This function relies on the GetEntryFromFile function.
			ArrayList entries = new ArrayList();
			DirectoryInfo guestBookDir = new DirectoryInfo(guestBookName);

			foreach (FileInfo fileItem in guestBookDir.GetFiles())
			{
				entries.Add(GetEntryFromFile(fileItem));
			}

			return entries;
		}

		private BookEntry GetEntryFromFile(FileInfo entryFile)
		{
			// Turn the file information into a Book Entry object.
			BookEntry newEntry = new BookEntry();
			StreamReader r = entryFile.OpenText();
			newEntry.Author = r.ReadLine();
			newEntry.Submitted = DateTime.Parse(r.ReadLine());
			newEntry.Message = r.ReadLine();
			r.Close();

			return newEntry;
		}

		private void SaveEntry(BookEntry entry)
		{
			// Create a new file for this entry, with a file name that should
			// be statistically unique.
			Random random = new Random();
			string fileName = guestBookName + @"\";
				fileName += DateTime.Now.Ticks.ToString() + random.Next(100).ToString();
			FileInfo newFile = new FileInfo(fileName);
			StreamWriter w = newFile.CreateText();

			// Write the information to the file.
			w.WriteLine(entry.Author);
			w.WriteLine(entry.Submitted.ToString());
			w.WriteLine(entry.Message);
			w.Flush();
			w.Close();
		}

	}


	public class BookEntry
	{
		private string author;
		private DateTime submitted;
		private string message;

		public string Author
		{
			get
			{ return author; }
			set
			{ author = value; }
		}

		public DateTime Submitted
		{
			get
			{ return submitted; }
			set
			{ submitted = value; }
		}

		public string Message
		{
			get
			{ return message; }
			set
			{ message = value; }
		}
	}

}
