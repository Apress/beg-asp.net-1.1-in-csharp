using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;

public class ShowSettings: Page
{
    protected Label lblTest;

    private void Page_Load()
    {
        lblTest.Text = "This app will connect with";
        lblTest.Text += "the connection string:<br><b>";
        lblTest.Text += 
          ConfigurationSettings.AppSettings["ConnectionString"];
        lblTest.Text += "</b><br><br>";
        lblTest.Text += "And will execute the SQL Statement:<br>";
        lblTest.Text += "<b>";
        lblTest.Text += ConfigurationSettings.AppSettings["SelectSales"];
        lblTest.Text += "</b>";
    }
}
