public class HelloWorldClass : System.Web.UI.Page
{
    protected System.Web.UI.WebControls.Label lblTest;

    private void Page_Load()
    {
        lblTest.Text = "Hello, the Page_Load event occurred.";
    }
}
