using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace RichControls
{
	/// <summary>
	/// Summary description for Appointment.
	/// </summary>
	public class Appointment : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Calendar Calendar1;
		protected System.Web.UI.WebControls.ListBox lstTimes;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Calendar1.DayRender += new System.Web.UI.WebControls.DayRenderEventHandler(this.Calendar1_DayRender);
			this.Calendar1.SelectionChanged += new System.EventHandler(this.Calendar1_SelectionChanged);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Calendar1_DayRender(object sender, System.Web.UI.WebControls.DayRenderEventArgs e)
		{
			// Check for May 5 in any year, and format it.
			if (e.Day.Date.Day == 5 && e.Day.Date.Month == 5)
			{
				e.Cell.BackColor = System.Drawing.Color.Yellow;

				// Add some static text to the cell.
				Label lbl = new Label();
				lbl.Text = "<br>My Birthday!";
				e.Cell.Controls.Add(lbl);
			}

		}

		private void Calendar1_SelectionChanged(object sender, System.EventArgs e)
		{
			lstTimes.Items.Clear();
			
			switch (Calendar1.SelectedDate.DayOfWeek)
			{
				case DayOfWeek.Monday:
					// Apply special Monday schedule.
					lstTimes.Items.Add("10:00");
					lstTimes.Items.Add("10:30");
					lstTimes.Items.Add("11:00");
					break;
				default:
					lstTimes.Items.Add("10:00");
					lstTimes.Items.Add("10:30");
					lstTimes.Items.Add("11:00");
					lstTimes.Items.Add("11:30");
					lstTimes.Items.Add("12:00");
					lstTimes.Items.Add("12:30");
					break;
			}

		}
	}
}
