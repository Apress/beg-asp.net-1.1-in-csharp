using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Validation
{
	/// <summary>
	/// Summary description for ManualValidation.
	/// </summary>
	public class ManualValidation : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.TextBox txtValidated;
		protected System.Web.UI.WebControls.RangeValidator RangeValidator;
		protected System.Web.UI.WebControls.TextBox txtNotValidated;
		protected System.Web.UI.WebControls.Button cmdOK;
		protected System.Web.UI.WebControls.Label lblMessage;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.cmdOK.Click += new System.EventHandler(this.cmdOK_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void cmdOK_Click(object sender, System.EventArgs e)
		{
			string errorMessage = "<b>Mistakes found:</b><br>";

			// Create a variable to represent the input control.
			TextBox ctrlInput;
			bool pageIsValid = true;
			// Search through the validation controls.
			foreach (BaseValidator ctrl in this.Validators)
			{
				
				if (!ctrl.IsValid)
				{
					pageIsValid = false;
					errorMessage += ctrl.ErrorMessage + "<br>";

					// Find the corresponding input control, and change the
					// generic Control variable into a TextBox variable.
					// This allows access to the Text property.
					ctrlInput = (TextBox)this.FindControl(ctrl.ControlToValidate);
					errorMessage += " * Problem is with this input: ";
					errorMessage += ctrlInput.Text + "<br>";
				}
			}
			if (!pageIsValid) lblMessage.Text = errorMessage;

			

		}
	}
}
