using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Validation
{
	/// <summary>
	/// Summary description for CustomerForm.
	/// </summary>
	public class CustomerForm : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.TextBox txtUserName;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.TextBox txtPassword;
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.TextBox txtRetype;
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.WebControls.Label Label4;
		protected System.Web.UI.WebControls.TextBox txtEmail;
		protected System.Web.UI.WebControls.TextBox txtAge;
		protected System.Web.UI.WebControls.Label Label5;
		protected System.Web.UI.WebControls.Label Label6;
		protected System.Web.UI.WebControls.TextBox txtCode;
		protected System.Web.UI.WebControls.RequiredFieldValidator vldUserName;
		protected System.Web.UI.WebControls.RequiredFieldValidator vldPassword;
		protected System.Web.UI.WebControls.CompareValidator vldRetype;
		protected System.Web.UI.WebControls.RegularExpressionValidator vldEmail;
		protected System.Web.UI.WebControls.RangeValidator vldAge;
		protected System.Web.UI.WebControls.CustomValidator vldCode;
		protected System.Web.UI.WebControls.Button cmdSubmit;
		protected System.Web.UI.WebControls.Button cmdCancel;
		protected System.Web.UI.WebControls.Label lblMessage;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.vldCode.ServerValidate += new System.Web.UI.WebControls.ServerValidateEventHandler(this.vldCode_ServerValidate);
			this.cmdSubmit.Click += new System.EventHandler(this.cmdSubmit_Click);
			this.cmdCancel.Click += new System.EventHandler(this.cmdCancel_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void cmdSubmit_Click(object sender, System.EventArgs e)
		{
			if (!this.IsValid) return;
			lblMessage.Text = "This is a valid form.";
		}

		private void cmdCancel_Click(object sender, System.EventArgs e)
		{
		    lblMessage.Text = "No attempt was made to validate this form.";
		}

		private void vldCode_ServerValidate(object source, System.Web.UI.WebControls.ServerValidateEventArgs e)
		{
			try
			{
				// Check if the first three digits are divisible by seven.
				int val = Int32.Parse(e.Value.Substring(0, 3));
				if (val % 7 == 0)
				{
					e.IsValid = true;
				}
				else
				{
					e.IsValid = false;
				}
			}
			catch
			{
				// An error occured in the conversion.
				// The value is not valid.
				e.IsValid = false;
			}
		}
	}
}
