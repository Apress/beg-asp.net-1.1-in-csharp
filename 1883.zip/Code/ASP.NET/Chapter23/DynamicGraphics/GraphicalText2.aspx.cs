using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace DynamicGraphics
{
	/// <summary>
	/// Summary description for GraphicalText2.
	/// </summary>
	public class GraphicalText2 : System.Web.UI.Page
	{
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Get the user name.
			if (Request.QueryString["Name"] == null)
			{
				// No name was supplied.
				// Don't display anything.
			}
			else
			{
				string name = Request.QueryString["Name"];

				// Create an in-memory bitmap where you will draw the image. 
				Bitmap image = new Bitmap(300, 50);

				// Get the graphics context for the bitmap.
				Graphics g = Graphics.FromImage(image);

				g.FillRectangle(Brushes.LightYellow, 0, 0, 300, 50);
				g.DrawRectangle(Pens.Red, 0, 0, 299, 49);

				// Draw some text based on the query string.
				Font font = new Font("Alba Super", 20, FontStyle.Regular);
				g.DrawString(name, font, Brushes.Blue, 10, 0);

				// Render the entire bitmap to the HTML output stream.
				image.Save(Response.OutputStream, 
					System.Drawing.Imaging.ImageFormat.Gif);

				g.Dispose();
				image.Dispose();
			}

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);
		}
		#endregion
	}
}
