using System;
using System.Web.UI.WebControls;
using System.Web.UI;

namespace CustomControls
{
	public class NameTextBox : TextBox
	{

		private string firstName;
		private string lastName;

		public string GetFirstName()
		{
			UpdateNames();
			return firstName;
		}

		public string GetLastName()
		{
			UpdateNames();
			return lastName;
		}

		private void UpdateNames()
		{
			int commaPos = Text.IndexOf(',');
			int spacePos = Text.IndexOf(' ');

			string[] nameArray;
			if (commaPos != -1)
			{
				nameArray = Text.Split(',');
				firstName = nameArray[1];
				lastName = nameArray[0];
			}
			else if (spacePos != -1)
			{
				nameArray = Text.Split(' ');
				firstName = nameArray[0];
				lastName = nameArray[1];
			}
			else
			{
				// The text has no comma or space.
				// It cannot be converted to a name.
				throw new InvalidOperationException();
			}
		}
	}

}
