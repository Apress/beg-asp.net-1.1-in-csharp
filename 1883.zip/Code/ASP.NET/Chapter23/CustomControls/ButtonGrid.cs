using System;
using System.Web.UI.WebControls;
using System.Web.UI;

namespace CustomControls
{
	public class ButtonGrid : WebControl,IPostBackEventHandler
	{
		public event GridClickEventHandler GridClick;
 
		public ButtonGrid()
		{
			ViewState["Rows"] = 2;
			ViewState["Cols"] = 2;
		}

		public int Cols
		{
			get
			{ return (int)ViewState["Cols"]; }
			set
			{ ViewState["Cols"] = value; }
		}

		public int Rows
		{
			get
			{ return (int)ViewState["Rows"]; }
			set
			{ ViewState["Rows"] = value; }
		}


		public virtual void RaisePostBackEvent(string eventArgument) 
		{
			if (GridClick != null)
			{
				GridClick(this, new GridClickEventArgs(eventArgument));
			}
		}

		protected override void CreateChildControls()
		{
			int k = 0;
			for (int i = 0; i < (int)ViewState["Rows"]; i++)
			{
				for (int j = 0; j < (int)ViewState["Cols"]; j++)
				{
					k++;

					// Create and configure a button.
					Button ctrlB = new Button();
					ctrlB.Width = Unit.Pixel(60);
					ctrlB.Text = k.ToString();

					ctrlB.Attributes["onClick"] = 
						Page.GetPostBackEventReference(this, ctrlB.Text);

					// Add the button.
					this.Controls.Add(ctrlB);
				}

				// Add a line break.
				LiteralControl ctrlL = new LiteralControl("<br>");
				this.Controls.Add(ctrlL);
			}
		}
	}


	public class GridClickEventArgs : EventArgs
	{
		public string ButtonName;
		public GridClickEventArgs(string buttonName)
		{
			ButtonName = buttonName;
		}

	}

	public delegate void GridClickEventHandler(object sender, 
	GridClickEventArgs e);


}