using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace CustomControlsTest
{
	/// <summary>
	/// Summary description for ButtonGridHost.
	/// </summary>
	public class ButtonGridHost : System.Web.UI.Page
	{
		protected CustomControls.ButtonGrid ButtonGrid1;
		protected System.Web.UI.WebControls.TextBox txtCols;
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.TextBox txtRows;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Button cmdUpdate;
		protected System.Web.UI.WebControls.Label lblInfo;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.ButtonGrid1.GridClick += new CustomControls.GridClickEventHandler(this.ButtonGrid1_GridClick);
			this.cmdUpdate.Click += new System.EventHandler(this.cmdUpdate_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void cmdUpdate_Click(object sender, System.EventArgs e)
		{
			ButtonGrid1.Rows = Int32.Parse(txtRows.Text);
			ButtonGrid1.Cols = Int32.Parse(txtCols.Text);

		}

		private void ButtonGrid1_GridClick(object sender, CustomControls.GridClickEventArgs e)
		{
			lblInfo.Text = "You clicked: " + e.ButtonName;
		}
	}
}
