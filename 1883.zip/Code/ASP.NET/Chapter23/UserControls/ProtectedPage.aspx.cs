using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace UserControls
{
	/// <summary>
	/// Summary description for ProtectedPage.
	/// </summary>
	public class ProtectedPage : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label lblSecretMessage;
		protected System.Web.UI.WebControls.Panel pnlControls;
	    protected LoginBox Login;

		private void Page_Load(object sender, System.EventArgs e)
		{
			Login.LoginAuthenticated += new LoginAuthenticatedEventHandler(Succeeded);
			Login.LoginFailed += new EventHandler(Failed);
		}

		private void Failed(object sender, EventArgs e)
		{
			// Retrieve the number of failed attempts from view state.
			int attempts = 0;
			if (ViewState["Attempts"] != null)
			{
				attempts = (int)ViewState["Attempts"];
			}

			attempts++;
			if (attempts > 3) pnlControls.Visible=false;

			// Store the new number of failed attempts in view state.
			ViewState["Attempts"] = attempts;
		}

		private void Succeeded(object sender, LoginAuthenticatedEventArgs e)
		{
			pnlControls.Enabled = false;
			lblSecretMessage.Text = "You are now authenticated";
			lblSecretMessage.Text += " to see this page, " + e.UserName;

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
