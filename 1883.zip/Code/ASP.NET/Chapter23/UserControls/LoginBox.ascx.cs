namespace UserControls
{
	using System;
	using System.Data;
	using System.Drawing;
	using System.Web;
	using System.Web.UI.WebControls;
	using System.Web.UI.HtmlControls;

	/// <summary>
	///		Summary description for LoginBox.
	/// </summary>
	public abstract class LoginBox : System.Web.UI.UserControl
	{
		protected System.Web.UI.WebControls.TextBox txtUser;
		protected System.Web.UI.WebControls.TextBox txtPassword;
		protected System.Web.UI.WebControls.Button cmdLogin;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Label Label2;

		public event EventHandler LoginFailed;
		public event LoginAuthenticatedEventHandler LoginAuthenticated;

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Typically, this code would use the FormsAuthentication
			// class described in Chapter 24, or some custom 
			// database-lookup code to authenticate the user.
			// This example simply checks for a "secret" code.
			if (txtPassword.Text == "opensesame")
			{
				if (LoginAuthenticated != null)
				{
					LoginAuthenticatedEventArgs eventInfo = 
						new LoginAuthenticatedEventArgs();
					eventInfo.UserName = txtUser.Text;
					LoginAuthenticated(this, eventInfo);
				}
			}
			else
			{
				if (LoginFailed != null)
				{
					// You can define the EventArgs object on the same line
					// that you use it to make more economical code.
					LoginFailed(this, new EventArgs());
				}
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}

	public delegate void LoginAuthenticatedEventHandler(object sender, LoginAuthenticatedEventArgs e);

	public class LoginAuthenticatedEventArgs : EventArgs
	{
		public string UserName;
	}

}
