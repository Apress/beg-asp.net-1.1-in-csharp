using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace StockQuoteClient
{
	/// <summary>
	/// Summary description for SimpleTest.
	/// </summary>
	public class SimpleTest : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label lblResult;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Create a StockInfo object for your results.
			localhost1.StockInfo wsInfo;

			// Create the actual web service proxy class.
			localhost1.StockQuote_DataObject ws = new localhost1.StockQuote_DataObject();

			// Call the web service method.
			wsInfo = ws.GetStockQuote("MSFT");

			lblResult.Text = wsInfo.CompanyName + " is at: " + wsInfo.Price.ToString();
			
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
