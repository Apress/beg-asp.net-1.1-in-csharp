using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace WindowsTerraClient
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		internal System.Windows.Forms.Label lblChoose;
		internal System.Windows.Forms.TextBox txtPlace;
		internal System.Windows.Forms.ListBox lstPlaces;
		internal System.Windows.Forms.Button cmdShow;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblChoose = new System.Windows.Forms.Label();
			this.txtPlace = new System.Windows.Forms.TextBox();
			this.lstPlaces = new System.Windows.Forms.ListBox();
			this.cmdShow = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// lblChoose
			// 
			this.lblChoose.Location = new System.Drawing.Point(28, 28);
			this.lblChoose.Name = "lblChoose";
			this.lblChoose.Size = new System.Drawing.Size(108, 12);
			this.lblChoose.TabIndex = 7;
			this.lblChoose.Text = "Choose a location:";
			// 
			// txtPlace
			// 
			this.txtPlace.Location = new System.Drawing.Point(152, 24);
			this.txtPlace.Name = "txtPlace";
			this.txtPlace.Size = new System.Drawing.Size(120, 20);
			this.txtPlace.TabIndex = 6;
			this.txtPlace.Text = "Kingston";
			// 
			// lstPlaces
			// 
			this.lstPlaces.Location = new System.Drawing.Point(28, 96);
			this.lstPlaces.Name = "lstPlaces";
			this.lstPlaces.Size = new System.Drawing.Size(316, 160);
			this.lstPlaces.TabIndex = 5;
			// 
			// cmdShow
			// 
			this.cmdShow.Location = new System.Drawing.Point(152, 48);
			this.cmdShow.Name = "cmdShow";
			this.cmdShow.Size = new System.Drawing.Size(120, 28);
			this.cmdShow.TabIndex = 4;
			this.cmdShow.Text = "Show All Matches";
			this.cmdShow.Click += new System.EventHandler(this.cmdShow_Click);
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(372, 281);
			this.Controls.AddRange(new System.Windows.Forms.Control[] {
																		  this.lblChoose,
																		  this.txtPlace,
																		  this.lstPlaces,
																		  this.cmdShow});
			this.Name = "Form1";
			this.Text = "Form1";
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		net.terraservice.TerraService ts = new net.terraservice.TerraService();

		private void cmdShow_Click(Object sender, EventArgs e) 
		{
			// Retrieve the matching list.
			net.terraservice.PlaceFacts[] factsArray;
			factsArray = ts.GetPlaceList(txtPlace.Text, 100, false);

			// Loop through all the results, and display them.
			foreach (net.terraservice.PlaceFacts facts in factsArray)
			{
				ShowPlaceFacts(facts);
			}
		}

		private void ShowPlaceFacts(net.terraservice.PlaceFacts facts)
		{
			string newItem;
			newItem = "Place: " + facts.Place.City + ", ";
			newItem += facts.Place.State + ", " + facts.Place.Country;
			lstPlaces.Items.Add(newItem);
		}

	}
}
