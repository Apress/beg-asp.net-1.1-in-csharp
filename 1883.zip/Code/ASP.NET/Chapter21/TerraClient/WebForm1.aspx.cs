using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace TerraClient
{
	/// <summary>
	/// Summary description for WebForm1.
	/// </summary>
	public class WebForm1 : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label lblResult;
		protected System.Web.UI.WebControls.Button cmdShow;
		protected System.Web.UI.WebControls.Button txtShowAll;
		protected System.Web.UI.WebControls.Button cmdShowPic;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.cmdShow.Click += new System.EventHandler(this.cmdShow_Click);
			this.txtShowAll.Click += new System.EventHandler(this.txtShowAll_Click);
			this.cmdShowPic.Click += new System.EventHandler(this.cmdShowPic_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private net.terraservice.TerraService ts = new net.terraservice.TerraService();

		private void cmdShow_Click(object sender, System.EventArgs e)
		{
			// Create the Place object for Seattle.
			net.terraservice.Place searchPlace = new net.terraservice.Place();
			searchPlace.City = "Seattle";
			searchPlace.Country = "USA";
			searchPlace.State = "Washington";

			// Define the PlaceFacts objects to retrieve your information.
			net.terraservice.PlaceFacts facts;

			// Call the web service method.
			facts = ts.GetPlaceFacts(searchPlace);

			// Display the results with the help of a subroutine.
			ShowPlaceFacts(facts);

		}

		private void ShowPlaceFacts(net.terraservice.PlaceFacts facts)
		{
			lblResult.Text += "<b>Place: " + facts.Place.City + "</b><br><br>";
			lblResult.Text += facts.Place.State + ", " + facts.Place.Country;
			lblResult.Text += "<br> Lat: " + facts.Center.Lat.ToString();
			lblResult.Text += "<br> Long: " + facts.Center.Lon.ToString();
			lblResult.Text += "<br><br>";
		}

		private void txtShowAll_Click(object sender, System.EventArgs e)
		{
			// Retrieve the matching list (for the city "Kingston").
			net.terraservice.PlaceFacts[] factsArray; 
			factsArray = ts.GetPlaceList("Kingston", 100, false);

			// Loop through all the results, and display them.
			foreach (net.terraservice.PlaceFacts facts in factsArray)
			{
				ShowPlaceFacts(facts);
			}

		}

		private void cmdShowPic_Click(object sender, System.EventArgs e)
		{
			// Define the search.
			net.terraservice.Place searchPlace = new net.terraservice.Place();
			searchPlace.City = "Seattle";
			searchPlace.Country = "USA";
			searchPlace.State = "Washington";

			// Get the PlaceFacts for Seattle.
			net.terraservice.PlaceFacts facts;
			facts = ts.GetPlaceFacts(searchPlace);

			// Retrieve information about the tile at the center of Seattle, using
			// the Scale and Theme enumerations from the terraservice namespace.
			net.terraservice.TileMeta tileData;
			tileData = ts.GetTileMetaFromLonLatPt(facts.Center, 
				net.terraservice.Theme.Photo, net.terraservice.Scale.Scale16m) ;

			// Retrieve the image.
			byte[] image = ts.GetTile(tileData.Id);

			// Display the image.
			Response.BinaryWrite(image);

		}

	}
}
