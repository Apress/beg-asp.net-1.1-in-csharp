using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.IO;
using System.Xml;

namespace SimpleXML
{
	/// <summary>
	/// Summary description for XmlDocuments.
	/// </summary>
	public class XmlDocuments : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Button cmdCreate;
		protected System.Web.UI.WebControls.Button cmdDisplay;
		protected System.Web.UI.WebControls.Button cmdSearch;
		protected System.Web.UI.WebControls.Label lblStatus;
		protected System.Web.UI.WebControls.DataGrid dgResults;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.cmdCreate.Click += new System.EventHandler(this.cmdCreate_Click);
			this.cmdDisplay.Click += new System.EventHandler(this.cmdDisplay_Click);
			this.cmdSearch.Click += new System.EventHandler(this.cmdSearch_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void cmdCreate_Click(object sender, System.EventArgs e)
		{
			lblStatus.Text = "";

			// Start with a blank in-memory document.
			XmlDocument doc = new XmlDocument();

			// Create some variables that will be useful for
			// manipulating XML data.
			XmlElement rootElement, productElement, priceElement;
			XmlAttribute productAttribute;
			XmlComment comment;

			// Create the declaration.
			XmlDeclaration declaration;
			declaration = doc.CreateXmlDeclaration("1.0", null, "yes");

			// Insert the declaration as the first node.
			doc.InsertBefore(declaration, doc.DocumentElement);

			// Add a comment.
			comment = doc.CreateComment("Created with the XmlDocument class.");
			doc.InsertAfter(comment, declaration);

			// Add the root node.
			rootElement = doc.CreateElement("SuperProProductList");
			doc.InsertAfter(rootElement, comment);

			// Add the first product.
			productElement = doc.CreateElement("Product");
			rootElement.AppendChild(productElement);

			// Set and add the product attributes.
			productAttribute = doc.CreateAttribute("ID");
			productAttribute.Value = "1";
			productElement.SetAttributeNode(productAttribute);
			productAttribute = doc.CreateAttribute("Name");
			productAttribute.Value = "Chair";
			productElement.SetAttributeNode(productAttribute);

			// Add the price node.
			priceElement = doc.CreateElement("Price");
			priceElement.InnerText = "49.33";
			productElement.AppendChild(priceElement);

			// Add the second product.
			productElement = doc.CreateElement("Product");
			rootElement.AppendChild(productElement);

			// Set and add the product attributes.
			productAttribute = doc.CreateAttribute("ID");
			productAttribute.Value = "2";
			productElement.SetAttributeNode(productAttribute);
			productAttribute = doc.CreateAttribute("Name");
			productAttribute.Value = "Car";
			productElement.SetAttributeNode(productAttribute);

			// Add the price node.
			priceElement = doc.CreateElement("Price");
			priceElement.InnerText = "43399.55";
			productElement.AppendChild(priceElement);

			// Add the third product.
			productElement = doc.CreateElement("Product");
			rootElement.AppendChild(productElement);

			// Set and add the product attributes.
			productAttribute = doc.CreateAttribute("ID");
			productAttribute.Value = "3";
			productElement.SetAttributeNode(productAttribute);
			productAttribute = doc.CreateAttribute("Name");
			productAttribute.Value = "Fresh Fruit Basket";
			productElement.SetAttributeNode(productAttribute);

			// Add the price node.
			priceElement = doc.CreateElement("Price");
			priceElement.InnerText = "49.99";
			productElement.AppendChild(priceElement);

			// Save the document.
			doc.Save(@"c:\SuperProProductList.xml");

			lblStatus.Text = @"File c:\SuperProProductList.xml written successfully.";
		}

		private void cmdDisplay_Click(object sender, System.EventArgs e)
		{
			// Create the document.
			XmlDataDocument doc = new XmlDataDocument();
			doc.Load(@"c:\SuperProProductList.xml");

			// Loop through all the nodes, and create the ArrayList..
			ArrayList products = new ArrayList();
			foreach (XmlElement element in doc.DocumentElement.ChildNodes)
			{
				Product newProduct = new Product();
				newProduct.ID = Int32.Parse(element.GetAttribute("ID"));
				newProduct.Name = element.GetAttribute("Name");

				// If there were more than one child node, you would probably use
				// another For Each loop here, and move through the
				// Element.ChildNodes collection.
				newProduct.Price = Decimal.Parse(element.ChildNodes[0].InnerText);

				products.Add(newProduct);
			}

			// Display the results.
			dgResults.DataSource = products;
			dgResults.DataBind();

		}

		private void cmdSearch_Click(object sender, System.EventArgs e)
		{
			XmlDataDocument doc = new XmlDataDocument();
			doc.Load(@"c:\SuperProProductList.xml");

			// Find the matches.
			XmlNodeList results = doc.GetElementsByTagName("Price");

			// Display the results.
			lblStatus.Text = "<b>Found " + results.Count.ToString() + " Matches ";
			lblStatus.Text += " for the Price tag: </b><br><br>";
			foreach (XmlNode result in results)
			{
				lblStatus.Text += result.FirstChild.Value + "<br>";
			}

		}
	}
}
