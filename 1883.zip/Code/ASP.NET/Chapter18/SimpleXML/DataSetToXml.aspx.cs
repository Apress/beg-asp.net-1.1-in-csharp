using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;
using System.Xml;

namespace SimpleXML
{
	/// <summary>
	/// Summary description for DataSetToXml.
	/// </summary>
	public class DataSetToXml : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Xml XmlControl;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			string connectionString = "Provider=SQLOLEDB.1;" + 
				"Data Source=localhost;Initial Catalog=pubs;Integrated Security=SSPI";
			string SQL = "SELECT * FROM authors WHERE city='Oakland'";

			// Create the ADO.NET objects.
			OleDbConnection con = new OleDbConnection(connectionString);
			OleDbCommand cmd = new OleDbCommand(SQL, con);
			OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
			DataSet ds = new DataSet("AuthorsDataSet");

			// Retrieve the data.
				con.Open();
			adapter.Fill(ds, "AuthorsTable");
			con.Close();

			// Create the XmlDataDocument that wraps this DataSet.
			XmlDataDocument dataDoc = new XmlDataDocument(ds) ;

			// Display the XML data (with the help of an XSLT) in the XML web control.
			XmlControl.Document = dataDoc ;
			XmlControl.TransformSource = "authors.xslt" ;

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
