using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

namespace ADO.NET
{
	/// <summary>
	/// Summary description for AuthorBrowser.
	/// </summary>
	public class AuthorBrowser : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.Label lblResults;
		protected System.Web.UI.WebControls.DropDownList lstAuthor;
	
		private string connectionString = "Provider=SQLOLEDB.1;" +
			"Data Source=localhost;Initial Catalog=pubs;Integrated Security=SSPI";

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!this.IsPostBack)
			{
				FillAuthorList();
			}
		}
       
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.lstAuthor.SelectedIndexChanged += new System.EventHandler(this.lstAuthor_SelectedIndexChanged);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void FillAuthorList()
		{
			lstAuthor.Items.Clear();

			// Define the Select statement.
			// Three pieces of information are needed: the unique id,
			// and the first and last name.
			string selectSQL;
			selectSQL = "SELECT au_lname, au_fname, au_id FROM Authors";

			// Define the ADO.NET objects.
			OleDbConnection con = new OleDbConnection(connectionString);
			OleDbCommand cmd = new OleDbCommand(selectSQL, con);
			OleDbDataReader reader;

			// Try to open database and read information.
			try
			{
				con.Open();
				reader = cmd.ExecuteReader();

				// For each item, add the author name to the displayed
				// list box text, and store the unique ID in the Value property.
				while (reader.Read())
				{
					ListItem newItem = new ListItem();
					newItem.Text = reader["au_lname"] + ", " + reader["au_fname"];
					newItem.Value = reader["au_id"].ToString();
					lstAuthor.Items.Add(newItem);
				}
				reader.Close();
			}
			catch (Exception err)
			{
				lblResults.Text = "Error reading list of names. ";
				lblResults.Text += err.Message;
			}
			finally
			{
				con.Close();
			}
		}

		private void lstAuthor_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			// Create a Select statement that searches for a record
			// matching the specific author id from the Value property.
			string selectSQL;
			selectSQL = "SELECT * FROM Authors ";
			selectSQL += "WHERE au_id='" + lstAuthor.SelectedItem.Value + "'";

			// Define the ADO.NET objects.
			OleDbConnection con = new OleDbConnection(connectionString);
			OleDbCommand cmd = new OleDbCommand(selectSQL, con);
			OleDbDataReader reader;

			// Try to open database and read information.
			try
			{
				con.Open();
				reader = cmd.ExecuteReader();
				reader.Read();
				lblResults.Text = "<b>" + reader["au_lname"];
				lblResults.Text += ", " + reader["au_fname"] + "</b><br>";
				lblResults.Text += "Phone: " + reader["phone"] + "<br>";
				lblResults.Text += "Address: " + reader["address"] + "<br>";
				lblResults.Text += "City: " + reader["city"] + "<br>";
				lblResults.Text += "State: " + reader["state"] + "<br>";
				reader.Close();
			}
			catch (Exception err)
			{
				lblResults.Text = "Error getting author. ";
				lblResults.Text += err.Message;
			}
			finally
			{
				con.Close();
			}

		}
	}
}
