using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

namespace ADO.NET
{
	/// <summary>
	/// Summary description for AuthorManager.
	/// </summary>
	public class AuthorManager_Parameterized : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.DropDownList lstAuthor;
		protected System.Web.UI.WebControls.Button cmdUpdate;
		protected System.Web.UI.WebControls.Button cmdDelete;
		protected System.Web.UI.WebControls.Label Label11;
		protected System.Web.UI.WebControls.Button cmdNew;
		protected System.Web.UI.WebControls.Button cmdInsert;
		protected System.Web.UI.WebControls.Panel pnlSelect;
		protected System.Web.UI.WebControls.Label Label10;
		protected System.Web.UI.WebControls.TextBox txtID;
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.TextBox txtFirstName;
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.WebControls.TextBox txtLastName;
		protected System.Web.UI.WebControls.Label Label4;
		protected System.Web.UI.WebControls.TextBox txtPhone;
		protected System.Web.UI.WebControls.Label Label5;
		protected System.Web.UI.WebControls.TextBox txtAddress;
		protected System.Web.UI.WebControls.Label Label6;
		protected System.Web.UI.WebControls.TextBox txtCity;
		protected System.Web.UI.WebControls.Label Label7;
		protected System.Web.UI.WebControls.TextBox txtState;
		protected System.Web.UI.WebControls.Label Label9;
		protected System.Web.UI.WebControls.TextBox txtZip;
		protected System.Web.UI.WebControls.Label Label8;
		protected System.Web.UI.WebControls.CheckBox chkContract;
		protected System.Web.UI.WebControls.Label lblStatus;
		protected System.Web.UI.WebControls.Panel Panel2;
	
		private string connectionString = "Provider=SQLOLEDB.1;" +
			"Data Source=localhost;Initial Catalog=pubs;Integrated Security=SSPI";

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!this.IsPostBack)
			{
				FillAuthorList();
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.lstAuthor.SelectedIndexChanged += new System.EventHandler(this.lstAuthor_SelectedIndexChanged);
			this.cmdUpdate.Click += new System.EventHandler(this.cmdUpdate_Click);
			this.cmdDelete.Click += new System.EventHandler(this.cmdDelete_Click);
			this.cmdNew.Click += new System.EventHandler(this.cmdNew_Click);
			this.cmdInsert.Click += new System.EventHandler(this.cmdInsert_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void FillAuthorList()
		{
			lstAuthor.Items.Clear();

			// Define the Select statement.
			// Three pieces of information are needed: the unique id,
			// and the first and last name.
			string selectSQL;
			selectSQL = "SELECT au_lname, au_fname, au_id FROM Authors";

			// Define the ADO.NET objects.
			OleDbConnection con = new OleDbConnection(connectionString);
			OleDbCommand cmd = new OleDbCommand(selectSQL, con);
			OleDbDataReader reader;

			// Try to open database and read information.
			try
			{
				con.Open();
				reader = cmd.ExecuteReader();

				// For each item, add the author name to the displayed
				// list box text, and store the unique ID in the Value property.
				while (reader.Read())
				{
					ListItem newItem = new ListItem();
					newItem.Text = reader["au_lname"] + ", " + reader["au_fname"];
					newItem.Value = reader["au_id"].ToString();
					lstAuthor.Items.Add(newItem);
				}
				reader.Close();
				lblStatus.Text = "";
			}
			catch (Exception err)
			{
				lblStatus.Text = "Error reading list of names. ";
				lblStatus.Text += err.Message;
			}
			finally
			{
				con.Close();
			}
		}

		private void lstAuthor_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			// Define ADO.NET objects.
			string selectSQL;
			selectSQL = "SELECT * FROM Authors ";
			selectSQL += "WHERE au_id='" + lstAuthor.SelectedItem.Value + "'";
			OleDbConnection con = new OleDbConnection(connectionString);
			OleDbCommand cmd = new OleDbCommand(selectSQL, con);
			OleDbDataReader reader;

			// Try to open database and read information.
			try
			{
				con.Open();
				reader = cmd.ExecuteReader();
				reader.Read();

				// Fill the controls.
				txtID.Text = reader["au_id"].ToString();
				txtFirstName.Text = reader["au_fname"].ToString();
				txtLastName.Text = reader["au_lname"].ToString();
				txtPhone.Text = reader["phone"].ToString();
				txtAddress.Text = reader["address"].ToString();
				txtCity.Text = reader["city"].ToString();
				txtState.Text = reader["state"].ToString();
				txtZip.Text = reader["zip"].ToString();
				chkContract.Checked = (bool)reader["contract"];
				reader.Close();
				lblStatus.Text = "";
			}
			catch (Exception err)
			{
				lblStatus.Text = "Error getting author. ";
				lblStatus.Text += err.Message;
			}
			finally
			{
				con.Close();
			}

		}

		private void cmdUpdate_Click(object sender, System.EventArgs e)
		{
			// Define ADO.NET objects.
			string updateSQL;
			updateSQL = "UPDATE Authors SET ";
			updateSQL += "au_id='" + txtID.Text + "', ";
			updateSQL += "au_fname='" + txtFirstName.Text + "', ";
			updateSQL += "au_lname='" + txtLastName.Text + "', ";
			updateSQL += "phone='" + txtPhone.Text + "', ";
			updateSQL += "address='" + txtAddress.Text + "', ";
			updateSQL += "city='" + txtCity.Text + "', ";
			updateSQL += "state='" + txtState.Text + "', ";
			updateSQL += "zip='" + txtZip.Text + "', ";
			updateSQL += "contract='" + Convert.ToInt16(chkContract.Checked) + "' ";
			updateSQL += "WHERE au_id='" + lstAuthor.SelectedItem.Value + "'";

			OleDbConnection con = new OleDbConnection(connectionString);
			OleDbCommand cmd = new OleDbCommand(updateSQL, con);

			// Try to open database and execute the update.
			try
			{
				con.Open();
				int updated = cmd.ExecuteNonQuery();
				lblStatus.Text = updated.ToString() + " records updated.";
			}
			catch (Exception err)
			{
				lblStatus.Text = "Error updating author. ";
				lblStatus.Text += err.Message;
			}
			finally
			{
				con.Close();
			}
		}

		private void cmdDelete_Click(object sender, System.EventArgs e)
		{
			// Define ADO.NET objects.
			string deleteSQL;
			deleteSQL = "DELETE FROM Authors ";
			deleteSQL += "WHERE au_id='" + lstAuthor.SelectedItem.Value + "'";

			OleDbConnection con = new OleDbConnection(connectionString);
			OleDbCommand cmd = new OleDbCommand(deleteSQL, con);

			// Try to open the database and delete the record.
			int deleted = 0;
			try
			{
				con.Open();
				deleted = cmd.ExecuteNonQuery();
			}
			catch (Exception err)
			{
				lblStatus.Text = "Error deleting author. ";
				lblStatus.Text += err.Message;
			}
			finally
			{
				con.Close();
			}

			// If the delete succeeded, refresh the author list.
			if (deleted > 0)
			{
				FillAuthorList();
			}
		}

		private void cmdNew_Click(object sender, System.EventArgs e)
		{
			txtID.Text = "";
			txtFirstName.Text = "";
			txtLastName.Text = "";
			txtPhone.Text = "";
			txtAddress.Text = "";
			txtCity.Text = "";
			txtState.Text = "";
			txtZip.Text = "";
			chkContract.Checked = false;

			lblStatus.Text = "Click Insert New to add the completed record.";
		}

		private void cmdInsert_Click(object sender, System.EventArgs e)
		{
			// Perform user-defined checks.
			// Alternatively, you could use RequiredFieldValidator controls.
			if (txtID.Text == "" || txtFirstName.Text == "" || txtLastName.Text == "")
			{
				lblStatus.Text = "Records require an ID, first name, and last name.";
				return;
			}

			// Define ADO.NET objects.
			string insertSQL;
			insertSQL = "INSERT INTO Authors (";
			insertSQL += "au_id, au_fname, au_lname, ";
			insertSQL += "phone, address, city, state, zip, contract) ";
			insertSQL += "VALUES (";
			insertSQL += "?, ?, ?, ?, ?, ?, ?, ?, ?)";

			OleDbConnection con = new OleDbConnection(connectionString);
			OleDbCommand cmd = new OleDbCommand(insertSQL, con);

			// Add the parameters.
			cmd.Parameters.Add("?", txtID.Text);
			cmd.Parameters.Add("?", txtFirstName.Text);
			cmd.Parameters.Add("?", txtLastName.Text);
			cmd.Parameters.Add("?", txtPhone.Text);
			cmd.Parameters.Add("?", txtAddress.Text);
			cmd.Parameters.Add("?", txtCity.Text);
			cmd.Parameters.Add("?", txtState.Text);
			cmd.Parameters.Add("?", txtZip.Text);
			cmd.Parameters.Add("?", Convert.ToInt16(chkContract.Checked));

			// Try to open the database and execute the update.
			int added = 0;
			try
			{
				con.Open();
				added = cmd.ExecuteNonQuery();
				lblStatus.Text = added.ToString() + " records inserted.";
			}
			catch (Exception err)
			{
				lblStatus.Text = "Error inserting record. ";
				lblStatus.Text += err.Message;
			}
			finally
			{
				con.Close();
			}

			// If the insert succeeded, refresh the author list.
			if (added > 0)
			{
				FillAuthorList();
			}

		}
	}
}
