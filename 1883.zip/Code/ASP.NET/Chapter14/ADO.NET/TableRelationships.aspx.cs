using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

namespace ADO.NET
{
	/// <summary>
	/// Summary description for TableRelationships.
	/// </summary>
	public class TableRelationships : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label lblList;
	
		private string connectionString = "Provider=SQLOLEDB.1;" +
			"Data Source=localhost;Initial Catalog=pubs;Integrated Security=SSPI";

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!this.IsPostBack)
			{
				CreateList();
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void CreateList()
		{
			// Define ADO.NET objects.
			string selectSQL = "SELECT au_lname, au_fname, au_id FROM Authors";
			OleDbConnection con = new OleDbConnection(connectionString);
			OleDbCommand cmd = new OleDbCommand(selectSQL, con);
			OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
			DataSet dsPubs = new DataSet();

			try
			{
				con.Open();
				adapter.Fill(dsPubs, "Authors");

				// This command is still linked to the data adapter.
				cmd.CommandText = "SELECT au_id, title_id FROM TitleAuthor";
				adapter.Fill(dsPubs, "TitleAuthor");

				// This command is still linked to the data adapter.
				cmd.CommandText = "SELECT title_id, title FROM Titles";
				adapter.Fill(dsPubs, "Titles");
			}
			catch (Exception err)
			{
				lblList.Text = "Error reading list of names. ";
				lblList.Text += err.Message;
			}
			finally
			{
				con.Close();
			}

			DataRelation Titles_TitleAuthor = new DataRelation("Titles_TitleAuthor", 
				dsPubs.Tables["Titles"].Columns["title_id"], 
				dsPubs.Tables["TitleAuthor"].Columns["title_id"]);
			DataRelation Authors_TitleAuthor = new DataRelation("Authors_TitleAuthor", 
				dsPubs.Tables["Authors"].Columns["au_id"], 
				dsPubs.Tables["TitleAuthor"].Columns["au_id"]);
			dsPubs.Relations.Add(Titles_TitleAuthor);
			dsPubs.Relations.Add(Authors_TitleAuthor);

			foreach (DataRow rowAuthor in dsPubs.Tables["Authors"].Rows)
			{
				lblList.Text += "<br><b>" + rowAuthor["au_fname"];
				lblList.Text += " " + rowAuthor["au_lname"] + "</b><br>";

				foreach (DataRow rowTitleAuthor in
					rowAuthor.GetChildRows(Authors_TitleAuthor))
				{
					foreach (DataRow rowTitle in
						rowTitleAuthor.GetParentRows(Titles_TitleAuthor))
					{
						lblList.Text += "&nbsp;&nbsp;";   
						lblList.Text += rowTitle["title"] + "<br>";
					}
				}
			}



		}
	}
}
