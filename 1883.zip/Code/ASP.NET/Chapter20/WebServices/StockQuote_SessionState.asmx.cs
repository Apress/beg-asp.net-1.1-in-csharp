using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.Services;

namespace WebServices
{
	[WebService(Description="Methods to get stock information.", 
		 Namespace="http://www.prosetech.com/Stocks")] 
	public class StockQuote_SessionState : System.Web.Services.WebService
	{
		public StockQuote_SessionState()
		{
			InitializeComponent();
		}

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion

		[WebMethod(EnableSession=true)]
		public decimal GetStockQuote(string ticker)
		{
			// Increment counters. This function locks the application
			// collection to prevent synchronization errors.
			Application.Lock();
			if (Application[ticker] == null)
			{
				Application[ticker] = 1;
			}
			else
			{
				Application[ticker] = (int)Application[ticker] + 1;
			}
			Application.UnLock();

			if (Session[ticker] == null)
			{
				Session[ticker] = 1;
			}
			else
			{
				Session[ticker] = (int)Session[ticker] + 1;
			}

			// Return a value representing the length of the ticker.
			return ticker.Length;
		}

		[WebMethod(EnableSession=true)]
		public CounterInfo GetStockUsage(string ticker)
		{
			CounterInfo result = new CounterInfo();
			if (Application[ticker] == null)
			{
				result.GlobalRequests = 0;
			}
			else
			{
				result.GlobalRequests = (int)Application[ticker];
			}
			Application.UnLock();

			if (Session[ticker] == null)
			{
				result.SessionRequests = 0;
			}
			else
			{
				result.SessionRequests = (int)Session[ticker];
			}
						
			return result;
		}

	}

	public class CounterInfo
	{
		public int GlobalRequests;
		public int SessionRequests;
	}

}
