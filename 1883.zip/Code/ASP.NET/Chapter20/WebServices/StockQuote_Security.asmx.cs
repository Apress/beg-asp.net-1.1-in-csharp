using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.Services;

namespace WebServices
{
	
	public class StockQuote_Security : System.Web.Services.WebService
	{
		public StockQuote_Security()
		{
			//CODEGEN: This call is required by the ASP.NET Web Services Designer
			InitializeComponent();
		}

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion

		[WebMethod]
		public LicenseKey Login(string id, string password) 
		{
			if (VerifyUser(id, password))
			{
				// Generate a license key made up of
				// some random sequence of characters.
				LicenseKey key = new LicenseKey();
				key.Key = Guid.NewGuid().ToString();

				// (The key would then be added to some temporary
				// license database.)

				return key;
			}
			else
			{
				// Cause an error that will be returned to the client.
				// The function uses a special SecurityException
				// from the .NET class library.
				throw new System.Security.SecurityException("Unauthorized.");
			}
		}

		[WebMethod]
		public int GetStockQuote(string ticker, LicenseKey key)
		{
			if (!VerifyKey(key))
			{
				throw new System.Security.SecurityException("Unauthorized.");
			}
			else
			{
				// Normal GetStockQuote code goes here.
				return ticker.Length;
			}
		}

		private bool VerifyUser(string id, string password)
		{
			// (Add database lookup code here to verify the user.
			//  In this example, you validate the user no matter what.)
			return true;
		}

		private bool VerifyKey(LicenseKey key)
		{
			// (Look up key in key database. If it's not there
			//  or it's expired, return false. In this example,
			//  you validate the user no matter what.)
			return true;
		}

	}
	public class LicenseKey
	{
		public string Key;
	}

}
