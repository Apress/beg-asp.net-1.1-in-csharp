using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.Services;

namespace WebServices
{
	[WebService(Description="Methods to get stock information.", 
	Namespace="http://www.prosetech.com/Stocks")] 
	public class StockQuote_DataObject : System.Web.Services.WebService
	{
		public StockQuote_DataObject()
		{
			//CODEGEN: This call is required by the ASP.NET Web Services Designer
			InitializeComponent();
		}

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion

		[WebMethod(Description="Gets a price quote for a stock.")]
		public StockInfo GetStockQuote(string ticker)
		{
			StockInfo quote = new StockInfo();
			quote.Symbol = ticker;
			quote = FillQuoteFromDB(quote);
			return quote;
		}

		private StockInfo FillQuoteFromDB(StockInfo lookup)
		{
			// You can add the appropriate database code here.
			// For test purposes this function hard-codes
			// some sample information.
			lookup.CompanyName = "Trapezoid";
			lookup.Price = 400;
			lookup.High_52Week = 410;
			lookup.Low_52Week = 20;
			return lookup;
		}

	}
	public class StockInfo
	{
		public decimal Price;
		public string Symbol;
		public decimal High_52Week;
		public decimal Low_52Week;
		public string CompanyName;
	}

}
