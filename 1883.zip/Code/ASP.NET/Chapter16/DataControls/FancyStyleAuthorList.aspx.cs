using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

namespace DataControls
{
	/// <summary>
	/// Summary description for FancyStyleAuthorList.
	/// </summary>
	public class FancyStyleAuthorList : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Button cmdUpdate;
		protected System.Web.UI.WebControls.TextBox txtColumns;
		protected System.Web.UI.WebControls.RadioButton optVertical;
		protected System.Web.UI.WebControls.RadioButton optHorizontal;
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.DataList listAuthor;
	
		private string connectionString = "Provider=SQLOLEDB.1;" +
			"Data Source=localhost;Initial Catalog=pubs;Integrated Security=SSPI";

		private void Page_Load(object sender, System.EventArgs e)
		{
			// Rebuild the table.
			string SQL = "SELECT * FROM Authors";
			OleDbConnection con = new OleDbConnection(connectionString);
			OleDbCommand cmd = new OleDbCommand(SQL, con);
			OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
			DataSet pubs = new DataSet();
			
			adapter.Fill(pubs, "Authors");
			listAuthor.DataSource = pubs.Tables["Authors"];
			
			if (!this.IsPostBack)
			{
				this.DataBind();
			}

		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.cmdUpdate.Click += new System.EventHandler(this.cmdUpdate_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void cmdUpdate_Click(object sender, System.EventArgs e)
		{
			listAuthor.RepeatColumns = Int32.Parse(txtColumns.Text);
			if (optVertical.Checked)
			{
				listAuthor.RepeatDirection = RepeatDirection.Vertical;
			}
			else
			{
				listAuthor.RepeatDirection = RepeatDirection.Horizontal;
			}
            this.DataBind();
		}
	}
}
