using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

namespace DataControls
{
	/// <summary>
	/// Summary description for DataListEdit.
	/// </summary>
	public class DataListEdit : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.DataList listAuthor;
		protected System.Web.UI.WebControls.Label lblStatus;
	
		private string connectionString = "Provider=SQLOLEDB.1;" +
			"Data Source=localhost;Initial Catalog=pubs;Integrated Security=SSPI";

		private void Page_Load(Object sender, EventArgs e)
		{
			if (!this.IsPostBack)
			{
				DataSet ds = GetDataSet();
				BindGrid(ds);
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.listAuthor.CancelCommand += new System.Web.UI.WebControls.DataListCommandEventHandler(this.listAuthor_CancelCommand);
			this.listAuthor.EditCommand += new System.Web.UI.WebControls.DataListCommandEventHandler(this.listAuthor_EditCommand);
			this.listAuthor.UpdateCommand += new System.Web.UI.WebControls.DataListCommandEventHandler(this.listAuthor_UpdateCommand);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void BindGrid(DataSet ds)
		{
			listAuthor.DataSource = ds.Tables["Authors"];
			this.DataBind();
		}

		private DataSet GetDataSet()
		{
			string SQL = "SELECT * FROM Authors";
			OleDbConnection con = new OleDbConnection(connectionString);
			OleDbCommand cmd = new OleDbCommand(SQL, con);
			OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
			DataSet dsPubs = new DataSet();
			adapter.Fill(dsPubs, "Authors");
			con.Close();
			return dsPubs;
		}

		private void listAuthor_EditCommand(object source, System.Web.UI.WebControls.DataListCommandEventArgs e)
		{
			listAuthor.EditItemIndex = e.Item.ItemIndex;
			DataSet ds = GetDataSet();
			BindGrid(ds);

		}

		private void listAuthor_CancelCommand(object source, System.Web.UI.WebControls.DataListCommandEventArgs e)
		{
			listAuthor.EditItemIndex = -1;
			DataSet ds = GetDataSet();
			BindGrid(ds);

		}

		private void listAuthor_UpdateCommand(object source, System.Web.UI.WebControls.DataListCommandEventArgs e)
		{
			// Create variables to hold new values.
			string newCity, newAddress;

			// Retrieve the new values.
			newCity = ((TextBox)e.Item.FindControl("txtCity")).Text;
			newAddress = ((TextBox)e.Item.FindControl("txtAddress")).Text;

			// Retrieve the author ID to look up the record.
			string id;
			id = ((Label)e.Item.FindControl("lblID")).Text;

				// Define the SQL Update statement.
				string update;
			update = "UPDATE Authors SET ";
			update += "city='" + newCity + "', ";
			update += "address='" + newAddress + "' ";
			update += "WHERE au_id='" + id + "'";

			// Create the ADO.NET objects.
			OleDbConnection con = new OleDbConnection(connectionString);
			OleDbCommand cmd = new OleDbCommand(update, con);

			// Try to open database and execute the update.
			try
			{
				con.Open();
				int numberUpdated = cmd.ExecuteNonQuery();
				lblStatus.Text = numberUpdated.ToString() + " records updated.";
			}
			catch (Exception err)
			{
				lblStatus.Text = "Error updating author. ";
				lblStatus.Text += err.Message;
			}
			finally
			{
				con.Close();
				}

			// Cancel edit mode.
			listAuthor.EditItemIndex = -1;

			// Rebind the grid.
			DataSet ds = GetDataSet();
			BindGrid(ds);

		}

	}
}
