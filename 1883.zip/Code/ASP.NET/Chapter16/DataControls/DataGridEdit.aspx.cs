using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

namespace DataControls
{
	/// <summary>
	/// Summary description for DataGridEdit.
	/// </summary>
	public class DataGridEdit : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label lblStatus;
		protected System.Web.UI.WebControls.DataGrid gridAuthor;
	
		private string connectionString = "Provider=SQLOLEDB.1;" +
			"Data Source=localhost;Initial Catalog=pubs;Integrated Security=SSPI";

		private void Page_Load(Object sender, EventArgs e)
		{
			if (!this.IsPostBack)
			{
				DataSet ds = GetDataSet();
				BindGrid(ds);
			}
		}

		private DataSet GetDataSet()
		{
			string SQL = "SELECT * FROM Authors";
			OleDbConnection con = new OleDbConnection(connectionString);
			OleDbCommand cmd = new OleDbCommand(SQL, con);
			OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
			DataSet dsPubs = new DataSet();
			adapter.Fill(dsPubs, "Authors");
			con.Close();
			return dsPubs;
		}

		private void BindGrid(DataSet ds)
		{
			gridAuthor.DataSource = ds.Tables["Authors"];
			this.DataBind();
		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.gridAuthor.PageIndexChanged += new System.Web.UI.WebControls.DataGridPageChangedEventHandler(this.gridAuthor_PageIndexChanged);
			this.gridAuthor.CancelCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.gridAuthor_CancelCommand);
			this.gridAuthor.EditCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.gridAuthor_EditCommand);
			this.gridAuthor.SortCommand += new System.Web.UI.WebControls.DataGridSortCommandEventHandler(this.gridAuthor_SortCommand);
			this.gridAuthor.UpdateCommand += new System.Web.UI.WebControls.DataGridCommandEventHandler(this.gridAuthor_UpdateCommand);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void gridAuthor_EditCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			gridAuthor.EditItemIndex = e.Item.ItemIndex;
			DataSet ds = GetDataSet();
			BindGrid(ds);

		}

		private void gridAuthor_CancelCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			gridAuthor.EditItemIndex = -1;
			DataSet ds = GetDataSet();
			BindGrid(ds);

		}

		private void gridAuthor_UpdateCommand(object source, System.Web.UI.WebControls.DataGridCommandEventArgs e)
		{
			// Create variables to hold new values.
			string newFirstName, newLastName;
			string newCity, newAddress;

			// Retrieve the new values.
			newFirstName = ((TextBox)e.Item.FindControl("txtfname")).Text;
			newLastName = ((TextBox)e.Item.FindControl("txtlname")).Text;
			newCity = ((TextBox)e.Item.Cells[2].Controls[0]).Text;
				newAddress = ((TextBox)e.Item.Cells[3].Controls[0]).Text;

					// Retrieve the author ID to look up the record.
					string id = e.Item.Cells[0].Text;

			// Define the SQL Update statement.
			string update;
			update = "UPDATE Authors SET ";
			update += "au_fname='" + newFirstName + "', ";
			update += "au_lname='" + newLastName + "', ";
			update += "city='" + newCity + "', ";
			update += "address='" + newAddress + "' ";
			update += "WHERE au_id='" + id + "'";

			// Create the ADO.NET objects.
			OleDbConnection con = new OleDbConnection(connectionString);
			OleDbCommand cmd = new OleDbCommand(update, con);

			// Try to open database and execute the update.
			try
			{
				con.Open();
				int NumberUpdated = cmd.ExecuteNonQuery();
				lblStatus.Text = NumberUpdated.ToString();
				lblStatus.Text += " records updated.";
			}
			catch (Exception err)
			{
				lblStatus.Text = "Error updating author. ";
				lblStatus.Text += err.Message;
			}
			finally
			{
				con.Close();
			}

			// Cancel edit mode.
			gridAuthor.EditItemIndex = -1;

			// Rebind the grid.
			DataSet ds = GetDataSet();
			BindGrid(ds);

		}

		private void gridAuthor_SortCommand(object source, System.Web.UI.WebControls.DataGridSortCommandEventArgs e)
		{
			DataSet ds = GetDataSet();

			// Apply the sort expression to the default view for the table.
			ds.Tables["Authors"].DefaultView.Sort = e.SortExpression;
			BindGrid(ds);

		}

		private void gridAuthor_PageIndexChanged(object source, System.Web.UI.WebControls.DataGridPageChangedEventArgs e)
		{
			// Set the new page.
			gridAuthor.CurrentPageIndex = e.NewPageIndex;

			// Rebind the grid.
			DataSet ds = GetDataSet();
			BindGrid(ds);

		}
	}
}
