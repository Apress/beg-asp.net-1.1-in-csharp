using System;
using System.Data;
using System.Data.OleDb;
using System.Configuration;

namespace DatabaseComponent
{
	public class DBUtil
	{
		private string connectionString;

		public DBUtil()
		{
			connectionString = ConfigurationSettings.AppSettings[
				"ConnectionString"];
			if (connectionString == null)
			{
				throw new ApplicationException(
					"Missing ConnectionString variable in web.config.");
			}

		}

		public DataSet GetCategories()
		{
			string query = "SELECT * FROM Categories";
			DataSet ds = FillDataSet(query, "Categories");
			return ds;
		}

		public DataSet GetItems()
		{
			string query = "SELECT * FROM Categories";
			DataSet ds = FillDataSet(query, "Items");
			return ds;
		}

		public DataSet GetItems(int categoryID) 
		{
			string query = "SELECT * FROM Items ";
			query += "WHERE Category_ID='" + categoryID + "'";
			DataSet ds = FillDataSet(query, "Items");
			return ds;
		}

		public void AddCategory(string name)
		{
			string insertSQL = "INSERT INTO Categories ";
			insertSQL += "(Name) VALUES ('" + name + "')";

			OleDbConnection con = new OleDbConnection(connectionString);
			OleDbCommand cmd = new OleDbCommand(insertSQL, con);

			con.Open();
			cmd.ExecuteNonQuery();
			con.Close();
		}

		public void AddItem(string title, string description, 
			decimal price, int categoryID)
		{
			string insertSQL = "INSERT INTO Items ";
			insertSQL += "(Title, Description, Price, Category_ID)";
			insertSQL += "VALUES ('" + title + "', '" + description + "', ";
			insertSQL += price + ", '" + categoryID + "')";

			OleDbConnection con = new OleDbConnection(connectionString);
			OleDbCommand cmd = new OleDbCommand(insertSQL, con);
			con.Open();
			cmd.ExecuteNonQuery();
			con.Close();
		}

		private DataSet FillDataSet(string query, string tableName)
		{
			OleDbConnection con = new OleDbConnection(connectionString);
			OleDbCommand cmd = new OleDbCommand(query, con);
			OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);

			DataSet ds = new DataSet();
			adapter.Fill(ds, tableName);
			con.Close();

			return ds;
		}

		public decimal GetAveragePrice()
		{
			string query = "SELECT AVG(Price) FROM Items";

			OleDbConnection con = new OleDbConnection(connectionString);
			OleDbCommand cmd = new OleDbCommand(query, con);

			con.Open();
			decimal average = (decimal)cmd.ExecuteScalar();
			con.Close();

			return average;
			}

		public int GetTotalItems()
		{
			string query = "SELECT Count(*) FROM Items";

			OleDbConnection con = new OleDbConnection(connectionString);
			OleDbCommand cmd = new OleDbCommand(query, con);

			con.Open();
			int count = (int)cmd.ExecuteScalar();
			con.Close();

			return count;
		}

	}
}