using System;

namespace DataObjectComponent
{
	public class Item
	{
		public int ID;
		public decimal Price;
		public string Description;

		private string title;
		public string Title
		{
			get
			{ return title; }
			set
			{ title = value; }
		}

		private string category;
		public string Category
		{
			get
			{ return category; }
			set
			{ category = value; }
		}
	}

	public class Category
	{
		private int id;
		public int ID
		{
			get
			{ return id; }
			set
			{ id = value; }
		}

		private string name;
		public string Name
		{
			get
			{ return name; }
			set
			{ name = value; }
		}
	}

}
