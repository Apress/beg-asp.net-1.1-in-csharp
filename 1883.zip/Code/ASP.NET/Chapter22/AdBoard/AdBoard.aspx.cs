using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace AdBoard
{
	/// <summary>
	/// Summary description for AdBoard.
	/// </summary>
	public class AdBoard : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label Label1;
		protected System.Web.UI.WebControls.DataGrid gridItems;
		protected System.Web.UI.WebControls.DropDownList lstCategories;
		protected System.Web.UI.WebControls.Button cmdDisplay;
		protected System.Web.UI.WebControls.Button cmdAdd;
		protected System.Web.UI.WebControls.Label Label2;
		protected System.Web.UI.WebControls.Label Label3;
		protected System.Web.UI.WebControls.Label Label4;
		protected System.Web.UI.WebControls.TextBox txtTitle;
		protected System.Web.UI.WebControls.TextBox txtPrice;
		protected System.Web.UI.WebControls.TextBox txtDescription;
		protected System.Web.UI.WebControls.Label Label5;
		protected System.Web.UI.WebControls.Panel pnlNew;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!this.IsPostBack)
			{
				DatabaseComponent.DBUtil DB = new DatabaseComponent.DBUtil();

				lstCategories.DataSource = DB.GetCategories();
				lstCategories.DataTextField = "Name";
				lstCategories.DataValueField = "ID";
				lstCategories.DataBind();
				pnlNew.Visible = false;
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.cmdDisplay.Click += new System.EventHandler(this.cmdDisplay_Click);
			this.cmdAdd.Click += new System.EventHandler(this.cmdAdd_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void cmdDisplay_Click(object sender, System.EventArgs e)
		{
			DatabaseComponent.DBUtil DB = new DatabaseComponent.DBUtil();

			gridItems.DataSource = DB.GetItems( 
				Int32.Parse(lstCategories.SelectedItem.Value));
			gridItems.DataBind();
			pnlNew.Visible = true;

		}

		private void cmdAdd_Click(object sender, System.EventArgs e)
		{
			DatabaseComponent.DBUtil DB = new DatabaseComponent.DBUtil();

			try
			{
				DB.AddItem(txtTitle.Text, txtDescription.Text, 
					Decimal.Parse(txtPrice.Text), Int32.Parse(lstCategories.SelectedItem.Value));

				gridItems.DataSource = DB.GetItems(
					Int32.Parse(lstCategories.SelectedItem.Value));
				gridItems.DataBind();
			}
			catch (FormatException err)
			{
				// An error occurs if the user has entered an
				// invalid price (non-numeric characters).
				// In this case, take no action.
				// Another option is to add a validator control
				// for the price text box.
			}

		}
	}
}
