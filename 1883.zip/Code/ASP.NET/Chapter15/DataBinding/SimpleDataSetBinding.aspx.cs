using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

namespace DataBindingTest
{
	/// <summary>
	/// Summary description for SimpleDataSetBinding.
	/// </summary>
	public class SimpleDataSetBinding : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.ListBox lstUser;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Define a DataSet with a single DataTable.
			DataSet dsInternal = new DataSet();
			dsInternal.Tables.Add("Users");

			// Define two columns for this table.
			dsInternal.Tables["Users"].Columns.Add("Name");
			dsInternal.Tables["Users"].Columns.Add("Country");

			// Add some actual information into the table.
			DataRow rowNew = dsInternal.Tables["Users"].NewRow();
			rowNew["Name"] = "John";
			rowNew["Country"] = "Uganda";
			dsInternal.Tables["Users"].Rows.Add(rowNew);

			rowNew = dsInternal.Tables["Users"].NewRow();
			rowNew["Name"] = "Samantha";
			rowNew["Country"] = "Belgium";
			dsInternal.Tables["Users"].Rows.Add(rowNew);

			rowNew = dsInternal.Tables["Users"].NewRow();
			rowNew["Name"] = "Rico";
			rowNew["Country"] = "Japan";
			dsInternal.Tables["Users"].Rows.Add(rowNew);

			// Define the binding.
			lstUser.DataSource = dsInternal.Tables["Users"];
			lstUser.DataTextField = "Name";

			this.DataBind();
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
