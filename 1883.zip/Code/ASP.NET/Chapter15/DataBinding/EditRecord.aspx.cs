using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;
using System.Data.OleDb;

namespace DataBindingTest
{
	/// <summary>
	/// Summary description for EditRecord.
	/// </summary>
	public class EditRecord : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.DropDownList lstProduct;
		protected System.Web.UI.WebControls.Button cmdUpdate;
		protected System.Web.UI.WebControls.Label lblChoose;
		protected System.Web.UI.WebControls.Label lblRecordInfo;
		protected System.Web.UI.WebControls.ListBox lstCategory;
	
		private string connectionString = "Provider=SQLOLEDB.1;" +
			"DataSource=localhost;Initial Catalog=Northwind;Integrated Security=SSPI";

		private void Page_Load(object sender, System.EventArgs e)
		{
			if (!this.IsPostBack)
			{
				// Define the ADO.NET objects for selecting Products.
				string SQL = "SELECT ProductName, ProductID FROM Products";
				OleDbConnection con = new OleDbConnection(connectionString);
				OleDbCommand cmd = new OleDbCommand(SQL, con);

				// Open the connection.
				con.Open();

				// Define the binding.
				lstProduct.DataSource = cmd.ExecuteReader();
				lstProduct.DataTextField = "ProductName";
				lstProduct.DataValueField = "ProductID";

				// Activate the binding.
				lstProduct.DataBind();

				con.Close();

				// Make sure nothing is currently selected.
				lstProduct.SelectedIndex = -1;
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.lstProduct.SelectedIndexChanged += new System.EventHandler(this.lstProduct_SelectedIndexChanged);
			this.cmdUpdate.Click += new System.EventHandler(this.cmdUpdate_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void lstProduct_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			// Create a command for selecting the matching product record.
			string selectProduct = "SELECT ProductName, QuantityPerUnit, " +
				"CategoryName FROM Products INNER JOIN Categories ON " +
				"Categories.CategoryID=Products.CategoryID " +
				"WHERE ProductID='" + lstProduct.SelectedItem.Value + " '";

			// Create the Connection and Command objects.
			OleDbConnection con = new OleDbConnection(connectionString);
			OleDbCommand cmdProducts = new OleDbCommand(selectProduct, con);

			// Retrieve the information for the selected product.
			con.Open();
			OleDbDataReader reader = cmdProducts.ExecuteReader();
			reader.Read();

			// Update the display.
			lblRecordInfo.Text = "<b>Product:</b> " + reader["ProductName"] + "<br>";
			lblRecordInfo.Text += "<b>Quantity:</b> " + reader["QuantityPerUnit"] + "<br>";
			lblRecordInfo.Text += "<b>Category:</b> " + reader["CategoryName"];

			// Store the corresponding CategoryName for future reference.
			string matchCategory = reader["CategoryName"].ToString();

			// Close the reader.
			reader.Close();

			// Create a new Command for selecting categories.
			string selectCategory = "SELECT CategoryName, CategoryID FROM Categories";
			OleDbCommand cmdCategories = new OleDbCommand(selectCategory, con);

			// Retrieve the category information, and bind it.
			lstCategory.DataSource = cmdCategories.ExecuteReader();
			lstCategory.DataTextField = "CategoryName";
			lstCategory.DataValueField = "CategoryID";
			lstCategory.DataBind();
			con.Close();

			// Highlight the matching category in the list.
			lstCategory.Items.FindByText(matchCategory).Selected = true;

			lstCategory.Visible = true;
			cmdUpdate.Visible = true;
		}

		private void cmdUpdate_Click(object sender, System.EventArgs e)
		{
			// Define the Command.
			string updateCommand = "UPDATE Products " +
				"SET CategoryID=" + lstCategory.SelectedItem.Value +
				" WHERE ProductID=" + lstProduct.SelectedItem.Value;

			OleDbConnection con = new OleDbConnection(connectionString);
			OleDbCommand cmd = new OleDbCommand(updateCommand, con);

			// Perform the update.
			con.Open();
			cmd.ExecuteNonQuery();
			con.Close();

		}
	}
}
