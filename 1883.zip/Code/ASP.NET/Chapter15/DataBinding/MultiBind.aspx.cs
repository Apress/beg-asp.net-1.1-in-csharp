using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace DataBindingTest
{
	/// <summary>
	/// Summary description for MultiBind.
	/// </summary>
	public class MultiBind : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.Label lblDynamic;
		protected System.Web.UI.WebControls.CheckBox chkDynamic;
		protected System.Web.UI.WebControls.HyperLink lnkDynamic;
		protected System.Web.UI.WebControls.Image imgDynamic;
		public string URL;

		private void Page_Load(Object sender, EventArgs e)
		{
			URL = Server.MapPath("picture.jpg");
			this.DataBind();
		}


		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion
	}
}
