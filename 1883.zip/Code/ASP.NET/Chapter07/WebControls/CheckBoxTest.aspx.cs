using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace WebControls
{

	public class CheckBoxTest : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.CheckBoxList chklst;
		protected System.Web.UI.WebControls.Button cmdOK;
		protected System.Web.UI.WebControls.Label lblResult;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			if (this.IsPostBack == false)
			{
				chklst.Items.Add("C");
				chklst.Items.Add("C++");
				chklst.Items.Add("C#");
				chklst.Items.Add("Visual Basic 6.0");
				chklst.Items.Add("VB.NET");
				chklst.Items.Add("Pascal");
			}
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.cmdOK.Click += new System.EventHandler(this.cmdOK_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void cmdOK_Click(object sender, System.EventArgs e)
		{
			lblResult.Text = "You chose:<b>";

			foreach (ListItem lstItem in chklst.Items)
			{
				if (lstItem.Selected == true)
				{
					// Add text to label.
					lblResult.Text += "<br>" + lstItem.Text;
				}
			}

			lblResult.Text += "</b>";
		}
	}
}
