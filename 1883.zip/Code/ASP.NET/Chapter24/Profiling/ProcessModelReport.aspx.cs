using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Profiling
{
	/// <summary>
	/// Summary description for ProcessModelReport.
	/// </summary>
	public class ProcessModelReport : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.DataGrid dgProcess;
		protected System.Web.UI.WebControls.Button cmdHistory;
		protected System.Web.UI.WebControls.Button cmdCurrent;
		protected System.Web.UI.WebControls.Label lblInfo;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.cmdHistory.Click += new System.EventHandler(this.cmdHistory_Click);
			this.cmdCurrent.Click += new System.EventHandler(this.cmdCurrent_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void cmdCurrent_Click(object sender, System.EventArgs e)
		{
			ProcessInfo current = ProcessModelInfo.GetCurrentProcessInfo();
			lblInfo.Text = "<b>Process: </b>" + current.ProcessID.ToString();
			lblInfo.Text += "<br><b>Start: </b>" + current.StartTime.ToString();
			lblInfo.Text += "<br><b>Age: </b>" + current.Age.ToString();
			lblInfo.Text += "<br><b>Peak Memory: </b>" + current.PeakMemoryUsed.ToString();
			lblInfo.Text += "<br><b>Status: </b>" + current.Status.ToString();

		}

		private void cmdHistory_Click(object sender, System.EventArgs e)
		{
			dgProcess.DataSource = ProcessModelInfo.GetHistory(100);
			dgProcess.DataBind();
		}
	}
}
