using System;
using System.Collections;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Web;
using System.Web.Services;
using System.Data.OleDb;

namespace DataCaching
{
	/// <summary>
	/// Summary description for DataCachingTest.
	/// </summary>
	public class DataCachingTest : System.Web.Services.WebService
	{
		public DataCachingTest()
		{
			//CODEGEN: This call is required by the ASP.NET Web Services Designer
			InitializeComponent();
		}

		#region Component Designer generated code
		
		//Required by the Web Services Designer 
		private IContainer components = null;
				
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if(disposing && components != null)
			{
				components.Dispose();
			}
			base.Dispose(disposing);		
		}
		
		#endregion

		string connectionString = "Provider=SQLOLEDB.1;" + 
		"Data Source=localhost;Initial Catalog=Pubs;Integrated Security=SSPI";

		[WebMethod()]
		public DataSet GetAuthorData()
		{
			// Return the full author DataSet (from the cache if possible).
			return GetAuthorDataSet();
		}

		[WebMethod()]
		public string[] GetAuthorNames()
		{
			// Get the customer DataSet (from the cache if possible).
			DataTable dt = GetAuthorDataSet().Tables[0];

			// Create an array that will hold the name of each customer.
			string[] names = new string[dt.Rows.Count];

			// Fill the array.
			int i = 0;
			foreach (DataRow row in dt.Rows)
			{
				names[i] = row["au_fname"] + " " + row["au_lname"];
				i++;
			}
			return names;
		}

		private DataSet GetAuthorDataSet()
		{
			System.Web.Caching.Cache cache;
			cache = HttpContext.Current.Cache ;

			// Check for cached item.
			DataSet ds = (DataSet)cache["DataSet"];
			if (ds == null)
			{
				// Recreate the item.
				ds = new DataSet("DataSet");
				OleDbConnection con = new OleDbConnection(connectionString);
				OleDbCommand cmd = new OleDbCommand("SELECT * FROM Authors", con);
				OleDbDataAdapter adapter = new OleDbDataAdapter(cmd);
				try
				{
					con.Open();
					adapter.Fill(ds, "Authors");
				}
				finally
				{
					con.Close();
				}

				// Store the item in the cache (for 60 seconds).
				cache.Insert("DataSet", ds, null, 
					DateTime.Now.AddSeconds(60), TimeSpan.Zero);
			}
			return ds;
		}

	}
}
