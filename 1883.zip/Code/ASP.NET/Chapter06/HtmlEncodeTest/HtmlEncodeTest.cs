using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;

public class HtmlEncodeTest : Page
{
    protected HtmlGenericControl ctrl1;
    protected HtmlGenericControl ctrl2;

    private void Page_Load()
    {
        ctrl1.InnerHtml = "To <b>bold</b> text use the <b> tag.";
        ctrl2.InnerHtml = "To <b>bold</b> text use the " + Server.HtmlEncode("<b>") + " tag.";
    }
}