using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

public class CurrencyConverter : Page
{
    protected HtmlGenericControl Result;
    protected HtmlInputButton Convert;
    protected HtmlInputText US;

    // This method runs automatically when
    // an instance of this class is created.
    protected override void OnInit(EventArgs e)
    {
        InitializeComponent();
	base.OnInit(e);
    }

    private void InitializeComponent()
    {
        // Connect all event handlers. 
        Convert.ServerClick += new EventHandler(this.Convert_ServerClick);
    }	

    private void Convert_ServerClick(Object sender, EventArgs e)
    {
        decimal USAmount = Decimal.Parse(US.Value);
        decimal euroAmount = USAmount * 1.12M;
        Result.InnerText = USAmount.ToString() + " US dollars = ";
        Result.InnerText += euroAmount.ToString() + " Euros.";
    }
}
