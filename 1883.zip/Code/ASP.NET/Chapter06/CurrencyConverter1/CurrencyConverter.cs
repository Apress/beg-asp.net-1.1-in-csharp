using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

public class CurrencyConverter : Page
{
    protected HtmlGenericControl Result;
    protected HtmlInputButton Convert;
    protected HtmlInputText US;

    protected void Convert_ServerClick(Object sender, EventArgs e)
    {
        decimal USAmount = decimal.Parse(US.Value);
        decimal euroAmount = USAmount * 1.12M;
        Result.InnerText = USAmount.ToString() + " US dollars = ";
        Result.InnerText += euroAmount.ToString() + " Euros.";
    }
}