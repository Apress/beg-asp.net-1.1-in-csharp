using System;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;

public class ImageTest : Page
{
    protected HtmlGenericControl Result;
    protected HtmlInputImage ImgButton;

    protected override void OnInit(EventArgs e)
    {
        InitializeComponent();
	base.OnInit(e);
    }

    private void InitializeComponent()
    {
        // Connect all event handlers. 
        ImgButton.ServerClick += 
          new ImageClickEventHandler(ImgButton_ServerClick);
    }	

    private void ImgButton_ServerClick(Object sender,
      ImageClickEventArgs e)
    {
        Result.InnerText = "You clicked at (" + e.X.ToString() + 
                           ", " + e.Y.ToString() + "). ";

        if ((e.Y < 100) && (e.Y > 20) && (e.X > 20) && (e.X < 275))
        {
            Result.InnerText += "You clicked on the button surface.";
        }
        else
        {
            Result.InnerText += "You clicked the button border.";
        }
    }
}
